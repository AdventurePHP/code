<?php
   /**
   *  @package core::registry
   *  @class Registry
   *
   *  Implements a factory for registry objects. In order to use the Registry, please obtain a
   *  singleton instance of the Registry.
   *
   *  @author Christian Achatz
   *  @version
   *  Version 0.1,19.06.2008<br />
   */
   class Registry
   {

      /**
      *  @private
      *  Stores the registry content.
      */
      var $__RegistryStore = array();


      function Registry(){
      }


      /**
      *  @public
      *
      *  Adds a registry value to the registry.<br />
      *
      *  @param string $Namespace; namespace of the entry
      *  @param string $Name; name of the entry
      *  @param string $Value; value of the entry
      *  @param bool $ReadOnly; true (value is read only) | false (value can be changed)
      *
      *  @author Christian Achatz
      *  @version
      *  Version 0.1,19.06.2008<br />
      */
      function register($Namespace,$Name,$Value,$ReadOnly = false){

         if(!isset($this->__RegistryStore[$Namespace][$Name]['readonly']) && $this->__RegistryStore[$Namespace][$Name]['readonly'] === true){
            trigger_error('[Registry::setEntry()] The entry with name "'.$Name.'" already exists and is read only! Please choose another entry name.',E_USER_WARNING);
          // end if
         }
         else{
            $this->__RegistryStore[$Namespace][$Name]['value'] = $Value;
            $this->__RegistryStore[$Namespace][$Name]['readonly'] = $ReadOnly;
          // end else
         }

       // end function
      }


      /**
      *  @public
      *
      *  Retrieves a registry value from the registry.<br />
      *
      *  @param string $Namespace; namespace of the entry
      *  @param string $Name; name of the entry
      *  @return void $Value; the desired value or null
      *
      *  @author Christian Achatz
      *  @version
      *  Version 0.1,19.06.2008<br />
      */
      function retrieve($Namespace,$Name){

         if(isset($this->__RegistryStore[$Namespace][$Name]['value'])){
            return $this->__RegistryStore[$Namespace][$Name]['value'];
          // end if
         }
         else{
            return null;
          // end else
         }

       // end function
      }

    // end class
   }
?>